/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.dolphinscheduler.dao.repository.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyCollection;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.apache.dolphinscheduler.common.utils.JSONUtils;
import org.apache.dolphinscheduler.dao.entity.Command;
import org.apache.dolphinscheduler.dao.entity.DsVersion;
import org.apache.dolphinscheduler.dao.entity.Environment;
import org.apache.dolphinscheduler.dao.entity.Project;
import org.apache.dolphinscheduler.dao.entity.Schedule;
import org.apache.dolphinscheduler.dao.entity.SerialCommand;
import org.apache.dolphinscheduler.dao.entity.Tenant;
import org.apache.dolphinscheduler.dao.entity.User;
import org.apache.dolphinscheduler.dao.entity.WorkFlowRelationDetail;
import org.apache.dolphinscheduler.dao.entity.WorkerGroup;
import org.apache.dolphinscheduler.dao.entity.WorkflowDefinitionLog;
import org.apache.dolphinscheduler.dao.entity.WorkflowInstanceRelation;
import org.apache.dolphinscheduler.dao.entity.WorkflowTaskLineage;
import org.apache.dolphinscheduler.dao.entity.WorkflowTaskRelationLog;
import org.apache.dolphinscheduler.dao.mapper.DsVersionMapper;
import org.apache.dolphinscheduler.dao.mapper.EnvironmentMapper;
import org.apache.dolphinscheduler.dao.mapper.ProjectMapper;
import org.apache.dolphinscheduler.dao.mapper.ProjectWorkerGroupMapper;
import org.apache.dolphinscheduler.dao.mapper.ScheduleMapper;
import org.apache.dolphinscheduler.dao.mapper.SerialCommandMapper;
import org.apache.dolphinscheduler.dao.mapper.SessionMapper;
import org.apache.dolphinscheduler.dao.mapper.TenantMapper;
import org.apache.dolphinscheduler.dao.mapper.UserMapper;
import org.apache.dolphinscheduler.dao.mapper.WorkerGroupMapper;
import org.apache.dolphinscheduler.dao.mapper.WorkflowDefinitionLogMapper;
import org.apache.dolphinscheduler.dao.mapper.WorkflowInstanceRelationMapper;
import org.apache.dolphinscheduler.dao.mapper.WorkflowTaskLineageMapper;
import org.apache.dolphinscheduler.dao.mapper.WorkflowTaskRelationLogMapper;
import org.apache.dolphinscheduler.dao.model.SerialCommandDto;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;

class DaoImplAdditionalTest {

    @Test
    void dsVersionDaoSelectVersionHandlesEmptyAndMultiple() {
        DsVersionMapper mapper = mock(DsVersionMapper.class);
        when(mapper.selectList(null)).thenReturn(Collections.emptyList());
        DsVersionDaoImpl dao = new DsVersionDaoImpl(mapper);
        Optional<DsVersion> empty = dao.selectVersion();
        assertTrue(!empty.isPresent());

        DsVersion v1 = new DsVersion();
        DsVersion v2 = new DsVersion();
        when(mapper.selectList(null)).thenReturn(Arrays.asList(v1, v2));
        Optional<DsVersion> result = dao.selectVersion();
        assertTrue(result.isPresent());
        assertEquals(v1, result.get());
    }

    @Test
    void environmentDaoQueryByCodeDelegates() {
        EnvironmentMapper mapper = mock(EnvironmentMapper.class);
        Environment env = new Environment();
        when(mapper.queryByEnvironmentCode(1L)).thenReturn(env);
        EnvironmentDaoImpl dao = new EnvironmentDaoImpl(mapper);
        Optional<Environment> result = dao.queryByEnvironmentCode(1L);
        assertEquals(env, result.get());
    }

    @Test
    void projectDaoQueriesDelegate() {
        ProjectMapper mapper = mock(ProjectMapper.class);
        Project project = new Project();
        when(mapper.queryByCode(1L)).thenReturn(project);
        when(mapper.queryByCodes(anyCollection())).thenReturn(Arrays.asList(project));

        ProjectDaoImpl dao = new ProjectDaoImpl(mapper);
        assertEquals(project, dao.queryByCode(1L));
        assertEquals(1, dao.queryByCodes(Arrays.asList(1L)).size());
    }

    @Test
    void projectWorkerGroupDaoHandlesDeleteAndQuery() {
        ProjectWorkerGroupMapper mapper = mock(ProjectWorkerGroupMapper.class);
        ProjectWorkerGroupDaoImpl dao = new ProjectWorkerGroupDaoImpl(mapper);

        when(mapper.deleteByProjectCode(1L)).thenReturn(1);
        assertTrue(dao.deleteByProjectCode(1L));

        when(mapper.queryAssignedWorkerGroupNamesByProjectCode(1L)).thenReturn(Collections.emptySet());
        assertTrue(dao.deleteByProjectCodeAndWorkerGroups(1L, Arrays.asList("wg")));

        when(mapper.queryAssignedWorkerGroupNamesByProjectCode(1L)).thenReturn(Collections.singleton("wg"));
        when(mapper.deleteByProjectCodeAndWorkerGroups(eq(1L), any())).thenReturn(1);
        assertTrue(dao.deleteByProjectCodeAndWorkerGroups(1L, Arrays.asList("wg")));

        when(mapper.queryAssignedWorkerGroupNamesByProjectCode(null)).thenReturn(null);
        assertNull(dao.queryAssignedWorkerGroupNamesByProjectCode(null));

        when(mapper.queryByProjectCode(1L)).thenReturn(Collections.emptyList());
        assertNotNull(dao.queryByProjectCode(1L));
    }

    @Test
    void scheduleDaoUsesBaseMethods() {
        ScheduleMapper mapper = mock(ScheduleMapper.class);
        Schedule schedule = new Schedule();
        when(mapper.selectById(1)).thenReturn(schedule);
        ScheduleDaoImpl dao = new ScheduleDaoImpl(mapper);
        assertEquals(schedule, dao.queryById(1));
    }

    @Test
    void serialCommandDaoFetchesAndDeletes() {
        SerialCommandMapper mapper = mock(SerialCommandMapper.class);
        Command command = new Command();
        SerialCommand serialCommand = SerialCommand.builder()
                .id(1)
                .workflowInstanceId(2)
                .workflowDefinitionCode(3L)
                .workflowDefinitionVersion(1)
                .command(JSONUtils.toJsonString(command))
                .state(0)
                .build();
        when(mapper.fetchSerialCommands(2)).thenReturn(Arrays.asList(serialCommand));
        when(mapper.deleteByWorkflowInstanceId(2)).thenReturn(1);

        SerialCommandDaoImpl dao = new SerialCommandDaoImpl(mapper);
        List<SerialCommandDto> results = dao.fetchSerialCommands(2);
        assertEquals(1, results.size());
        assertEquals(1, dao.deleteByWorkflowInstanceId(2));
    }

    @Test
    void sessionDaoQueryAndDeleteDelegate() {
        SessionMapper mapper = mock(SessionMapper.class);
        SessionDaoImpl dao = new SessionDaoImpl(mapper);
        dao.deleteByUserId(1);
        verify(mapper).delete(any());

        when(mapper.selectList(any())).thenReturn(Collections.emptyList());
        assertEquals(0, dao.queryByUserId(1).size());
    }

    @Test
    void tenantDaoUsesBaseMethods() {
        TenantMapper mapper = mock(TenantMapper.class);
        Tenant tenant = new Tenant();
        when(mapper.selectById(1)).thenReturn(tenant);
        TenantDaoImpl dao = new TenantDaoImpl(mapper);
        assertEquals(tenant, dao.queryById(1));
    }

    @Test
    void userDaoUsesBaseMethods() {
        UserMapper mapper = mock(UserMapper.class);
        User user = new User();
        when(mapper.selectById(1)).thenReturn(user);
        UserDaoImpl dao = new UserDaoImpl(mapper);
        assertEquals(user, dao.queryById(1));
    }

    @Test
    void workerGroupDaoQueriesAndDeletes() {
        WorkerGroupMapper mapper = mock(WorkerGroupMapper.class);
        WorkerGroup group = new WorkerGroup();
        group.setName("wg");
        when(mapper.deleteByWorkerGroupName("wg")).thenReturn(1);
        when(mapper.queryAllWorkerGroup()).thenReturn(Arrays.asList(group));
        when(mapper.queryWorkerGroupByName("wg")).thenReturn(Arrays.asList(group));

        WorkerGroupDaoImpl dao = new WorkerGroupDaoImpl(mapper);
        assertTrue(dao.deleteByWorkerGroupName("wg"));
        assertEquals(Arrays.asList("wg"), dao.queryAllWorkerGroupNames());
        assertEquals(1, dao.queryWorkerGroupByName("wg").size());
    }

    @Test
    void workflowDefinitionLogDaoQueriesAndDeletes() {
        WorkflowDefinitionLogMapper mapper = mock(WorkflowDefinitionLogMapper.class);
        WorkflowDefinitionLog log = new WorkflowDefinitionLog();
        when(mapper.queryByDefinitionCodeAndVersion(1L, 1)).thenReturn(log);
        WorkflowDefinitionLogDaoImpl dao = new WorkflowDefinitionLogDaoImpl(mapper);
        assertEquals(log, dao.queryByDefinitionCodeAndVersion(1L, 1));
        dao.deleteByWorkflowDefinitionCode(1L);
        verify(mapper).deleteByWorkflowDefinitionCode(1L);
    }

    @Test
    void workflowInstanceMapDaoQueriesDelegate() {
        WorkflowInstanceRelationMapper mapper = mock(WorkflowInstanceRelationMapper.class);
        WorkflowInstanceRelation relation = new WorkflowInstanceRelation();
        when(mapper.queryByParentId(1, 2)).thenReturn(relation);
        when(mapper.querySubIdListByParentId(1)).thenReturn(Arrays.asList(2, 3));
        WorkflowInstanceMapDaoImpl dao = new WorkflowInstanceMapDaoImpl(mapper);
        assertEquals(relation, dao.queryWorkflowMapByParent(1, 2));
        assertEquals(2, dao.querySubWorkflowInstanceIds(1).size());
        dao.deleteByParentId(1);
        verify(mapper).deleteByParentId(1);
    }

    @Test
    void workflowTaskRelationLogDaoHandlesBatchInsert() {
        WorkflowTaskRelationLogMapper mapper = mock(WorkflowTaskRelationLogMapper.class);
        WorkflowTaskRelationLog log = new WorkflowTaskRelationLog();
        when(mapper.batchInsert(any())).thenReturn(2);
        WorkflowTaskRelationLogDaoImpl dao = new WorkflowTaskRelationLogDaoImpl(mapper);
        assertEquals(0, dao.batchInsert(Collections.<WorkflowTaskRelationLog>emptyList()));
        assertEquals(2, dao.batchInsert(Arrays.asList(log, log)));
    }

    @Test
    void workflowTaskLineageDaoUpdatesAndQueries() {
        WorkflowTaskLineageMapper mapper = mock(WorkflowTaskLineageMapper.class);
        WorkflowTaskLineage lineage = new WorkflowTaskLineage();
        lineage.setWorkflowDefinitionCode(1L);
        when(mapper.batchDeleteByWorkflowDefinitionCode(any())).thenReturn(1);
        when(mapper.batchInsert(any())).thenReturn(1);
        when(mapper.queryByProjectCode(1L)).thenReturn(Collections.emptyList());
        when(mapper.queryWorkFlowLineageByCode(1L)).thenReturn(Collections.<WorkFlowRelationDetail>emptyList());
        when(mapper.queryWorkFlowLineageByName(1L, "wf")).thenReturn(Collections.<WorkFlowRelationDetail>emptyList());
        when(mapper.queryWorkFlowLineageByDept(1L, 2L, 3L)).thenReturn(Collections.emptyList());
        when(mapper.queryByWorkflowDefinitionCode(1L)).thenReturn(Collections.emptyList());

        WorkflowTaskLineageDaoImpl dao = new WorkflowTaskLineageDaoImpl(mapper);
        assertEquals(0, dao.batchDeleteByWorkflowDefinitionCode(Collections.<Long>emptyList()));
        assertEquals(0, dao.batchInsert(Collections.<WorkflowTaskLineage>emptyList()));
        assertEquals(1, dao.updateWorkflowTaskLineage(Arrays.asList(lineage)));
        assertEquals(0, dao.queryByProjectCode(1L).size());
        assertEquals(0, dao.queryWorkFlowLineageByCode(1L).size());
        assertEquals(0, dao.queryWorkFlowLineageByName(1L, "wf").size());
        assertEquals(0, dao.queryWorkFlowLineageByDept(1L, 2L, 3L).size());
        assertEquals(0, dao.queryByWorkflowDefinitionCode(1L).size());
    }
}
