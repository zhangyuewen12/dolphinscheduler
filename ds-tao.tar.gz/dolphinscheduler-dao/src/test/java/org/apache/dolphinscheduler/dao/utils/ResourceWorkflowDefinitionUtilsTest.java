/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.dolphinscheduler.dao.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

/**
 * resource process definition utils test
 */
public class ResourceWorkflowDefinitionUtilsTest {

    @Test
    public void getResourceProcessDefinitionMapTest() {
        List<Map<String, Object>> mapList = new ArrayList<>();
        Map<String, Object> map = new HashMap<>();
        map.put("code", 1L);
        map.put("resource_ids", "1,2,3");
        mapList.add(map);
        Map<Integer, Set<Long>> result =
                ResourceProcessDefinitionUtils.getResourceProcessDefinitionMap(mapList);
        Assertions.assertEquals(3, result.size());
        Assertions.assertTrue(result.get(1).contains(1L));
        Assertions.assertTrue(result.get(2).contains(1L));
        Assertions.assertTrue(result.get(3).contains(1L));
    }

    @Test
    public void getResourceProcessDefinitionMapTest_multipleCodesAndDuplicates() {
        List<Map<String, Object>> mapList = new ArrayList<>();

        Map<String, Object> map1 = new HashMap<>();
        map1.put("code", 1L);
        map1.put("resource_ids", "1,2,2");
        mapList.add(map1);

        Map<String, Object> map2 = new HashMap<>();
        map2.put("code", 2L);
        map2.put("resource_ids", "2,3");
        mapList.add(map2);

        Map<Integer, Set<Long>> result =
                ResourceProcessDefinitionUtils.getResourceProcessDefinitionMap(mapList);

        Assertions.assertEquals(3, result.size());
        Assertions.assertEquals(new HashSet<Long>(Arrays.asList(1L)), result.get(1));
        Assertions.assertEquals(new HashSet<Long>(Arrays.asList(1L, 2L)), result.get(2));
        Assertions.assertEquals(new HashSet<Long>(Arrays.asList(2L)), result.get(3));
    }

    @Test
    public void getResourceProcessDefinitionMapTest_emptyList() {
        Map<Integer, Set<Long>> result =
                ResourceProcessDefinitionUtils.getResourceProcessDefinitionMap(new ArrayList<Map<String, Object>>());
        Assertions.assertTrue(result.isEmpty());
    }

    @Test
    public void getResourceObjectMapTest() {
        List<Map<String, Object>> mapList = new ArrayList<>();
        Map<String, Object> map = new HashMap<>();
        map.put("task_id", 10);
        map.put("resource_ids", "4,5");
        mapList.add(map);

        Map<Integer, Set<Integer>> result =
                ResourceProcessDefinitionUtils.getResourceObjectMap(mapList, "task_id", Integer.class);

        Assertions.assertEquals(2, result.size());
        Assertions.assertTrue(result.get(4).contains(10));
        Assertions.assertTrue(result.get(5).contains(10));
    }
}
